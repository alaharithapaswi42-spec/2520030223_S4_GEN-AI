import os
import time
from dotenv import load_dotenv
from google import genai
from google.genai.errors import ServerError

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("Gemini API key not found. Check your .env file.")

client = genai.Client(api_key=api_key)

for attempt in range(5):
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents="What is Artificial Intelligence? Explain in simple words."
        )

        print("\nGemini Response:")
        print(response.text)
        break

    except ServerError as error:
        print("Gemini server is busy. Retrying...")
        if attempt == 4:
            print("Please try again later.")
            print(error)
        else:
            time.sleep(10 * (attempt + 1))